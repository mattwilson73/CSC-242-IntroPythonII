
def recProd(k,n):
    pass

def printTriangle(m,i):
    pass
